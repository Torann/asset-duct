<?php namespace Torann\Assets;

use Illuminate\Foundation\AliasLoader;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

use Torann\Assets\Console\SetupCommand;
use Torann\Assets\Console\PublishCommand;

class ServiceProvider extends \Illuminate\Support\ServiceProvider
{
	/**
	 * Indicates if loading of the provider is deferred.
	 *
	 * @var bool
	 */
	protected $defer = false;

	/**
	 * Bootstrap the application events.
	 *
	 * @return void
	 */
	public function boot()
	{
		// Register the package namespace
		$this->package('torann/assets');

		// Add 'Assets' facade alias
		AliasLoader::getInstance()->alias('Assets', 'Torann\Assets\Facade');

        // Load the local manifest that contains the fingerprinted
        // paths to production builds.
        $this->app['torann.manifest']->load();

        // Register route for assets in no prod evn
        if (! $this->app['torann.assets']->inProduction()) {
            $this->registerFilter();
        }
	}

	/**
	 * Register the service provider.
	 *
	 * @return void
	 */
	public function register()
	{
        $this->registerManifest();
        $this->registerAssets();
		$this->registerBladeExtensions();
		$this->registerCommands();
	}

    /**
     * Register the collection repository.
     *
     * @return void
     */
    protected function registerManifest()
    {
        $this->app['torann.manifest'] = $this->app->share(function($app)
        {
            $meta = $app['config']->get('app.manifest');

            return new Manifest($app['files'], $meta);
        });
    }

    /**
     * Register the asset manager.
     *
     * @return void
     */
    protected function registerAssets()
    {
        $this->app['torann.assets'] = $this->app->share(function($app)
        {
            // Read settings from config file
            $config = $app->config->get('assets::config', array());
            $config['public_dir'] = public_path();

            // In production?
            $inProduction = in_array($app['env'], (array) $config['production']);

            // Create instance
            return new Manager($config, $app['torann.manifest'], $inProduction);
        });
    }

    /**
     * Register the Blade extensions with the compiler.
     *
     * @return void
     */
    protected function registerBladeExtensions()
    {
        $blade = $this->app['view']->getEngineResolver()->resolve('blade')->getCompiler();

        // JavaScript extension
        $blade->extend(function($value)
        {
            $matcher = "/(?<!\w)(\s*)@javascript\(['|\"](([[:alnum:]]|_)+.*)['|\"]((\,(.*))*)?\)/";
            return preg_replace_callback($matcher, function ($match)
            {
                return $match[1].$this->app['torann.assets']->bladeHtml($match[2]);
            }, $value);
        });

        // Stylesheet extension
        $blade->extend(function($value)
        {
            $matcher = "/(?<!\w)(\s*)@stylesheet\(['|\"](([[:alnum:]]|_)+.*)['|\"]((\,(.*))*)?\)/";
            return preg_replace_callback($matcher, function ($match)
            {
                return $match[1].$this->app['torann.assets']->bladeHtml($match[2]);
            }, $value);
        });

        // Image extension
        $blade->extend(function($value)
        {
            $matcher = "/@image\(['|\"](([[:alnum:]]|_|\/)+.*)['|\"]\)/";
            return preg_replace_callback($matcher, function ($match)
            {
                return $this->app['torann.assets']->bladeImage($match[1]);
            }, $value);
        });
    }

    /**
     * Extend HTML.
     *
     * @return void
     */
    public function registerHtmlExtenders()
    {
        $this->app['html'] = $this->app->share(function ($app)
        {
            // Read settings from config file
            $enabled = $app['config']->get('app.cachebuster::enabled', false);

            return new Builder($app['url'], $app['files'], $enabled);
        });
    }

    /**
     * Register the commands.
     *
     * @return void
     */
    public function registerCommands()
    {
        $this->app['assets.setup'] = $this->app->share(function($app)
        {
            return new SetupCommand();
        });

        $this->app['assets.publish'] = $this->app->share(function($app)
        {
            return new PublishCommand($app['torann.assets'], $app['files']);
        });

        $this->commands('assets.setup');
        $this->commands('assets.publish');
    }

    /**
     * Register missing asset filter.
     *
     * @return void
     */
    private function registerFilter()
    {
        // Ductwork instance
        $manager = $this->app['torann.assets'];

        // Add before filter for static assets
        $this->app->before(function ($request, $response) use ($manager)
        {
            // Assets public location
            $asset_dir = $manager->getConfig('asset_dir');

            // Request path
            $path = $request->path();

            if (starts_with($path, $asset_dir))
            {
                $source_path = $manager->getAssetSource($path);

                if ($source_path) {
                    return new BinaryFileResponse($source_path, 200);
                }
            }
        });
    }

	/**
	 * Get the services provided by the provider.
	 *
	 * @return array
	 */
	public function provides()
	{
		return array();
	}

}
